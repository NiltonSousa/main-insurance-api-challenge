export type * from "./create-partner";
export type * from "./create-quote";
export type * from "./create-policy";
export type * from "./get-policy";

export type SexType = ["m/M", "f/F", "n/N"];
