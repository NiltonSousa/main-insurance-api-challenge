export type * from "./partner-repository";
export type * from "./quote-repository";
export type * from "./policy-repository";
