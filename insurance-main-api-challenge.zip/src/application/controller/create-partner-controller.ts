import type { Partner } from "@/domain/entity";
import type {
  ICreatePartnerUseCase,
  ICreatePartnerUseCaseInput,
} from "@/domain/usecase";
import type { IController } from "./controller";
import type { JoiValidator } from "@/main/adapters";

export class CreatePartnerController
  implements IController<ICreatePartnerUseCaseInput, Partner>
{
  constructor(
    private readonly createPartnerUseCase: ICreatePartnerUseCase,
    private readonly validator: JoiValidator<unknown>
  ) {}

  async control(input: ICreatePartnerUseCaseInput): Promise<Partner> {
    const validation = this.validator.validate(input);

    if (validation.invalid) {
      throw new Error(validation.message);
    }

    return await this.createPartnerUseCase.execute(input);
  }
}
