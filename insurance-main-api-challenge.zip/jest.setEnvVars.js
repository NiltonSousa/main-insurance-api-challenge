DATABASE_URL = "file:./test.db"
INSURANCE_API_KEY = "Ea8xNE2q2kRuWqR"
INSURANCE_API_BASE_URL = "http://localhost:8080"